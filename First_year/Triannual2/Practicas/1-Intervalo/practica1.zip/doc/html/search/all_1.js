var searchData=
[
  ['getcotainf',['getCotaInf',['../classIntervalo.html#af8170b68c6d6a63192db6685b90f782f',1,'Intervalo']]],
  ['getcotasup',['getCotaSup',['../classIntervalo.html#a7f8ff94ce16f90a81a3c55f36044893b',1,'Intervalo']]]
];
