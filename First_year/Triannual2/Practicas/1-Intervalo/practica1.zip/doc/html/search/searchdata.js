var indexSectionsWithContent =
{
  0: "egil",
  1: "i",
  2: "i",
  3: "egil"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones"
};

